import React from 'react';
import { Image } from 'react-native';
import Home from '../components/screens/Home';
import Cats from '../components/screens/Cats';
import Dogs from '../components/screens/Dogs';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';

export default function Navigation(){

  const Tab = createBottomTabNavigator();

 return(
  <Tab.Navigator>
    <Tab.Screen 
      name="home" 
      component={Home} 
      options={{
        title:'Home',
        tabBarIcon: ()=> (<Image source={require("../images/home.png")} 
        style={{width: 20,height: 20}}/>)}}
    />
    <Tab.Screen 
      name="cats" 
      component={Cats} 
      options={{
        title:'Cats',
        tabBarIcon: ()=> (<Image source={require("../images/cats/cat.png")} 
        style={{width: 25,height: 30}}/>)}}
    />
    <Tab.Screen 
      name="dogs" 
      component={Dogs} 
      options={{
        title:'Dogs', 
        tabBarIcon: ()=> (<Image source={require("../images/dogs/perro.jpg")} 
        style={{width: 25,height: 30}}/>)}}
    />
  </Tab.Navigator>
 )
}