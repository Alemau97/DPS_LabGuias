import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import Dogs from '../components/screens/Dogs';

const Stack= createStackNavigator();

export default function DogsStack(){

 return(
  <Stack.Navigator>
    <Stack.Screen name="dogs" component={Dogs} options={{title:'Dogs'}}/>
  </Stack.Navigator>
 )
}