import React from 'react';
import {View,Text, Image, ScrollView, StyleSheet, SafeAreaView} from 'react-native';

const styles = StyleSheet.create({
  container: {
    width: '100%'
  },  
  title: {
    padding: 5,
    fontSize: 20,
    textAlign: 'center'
  },
  cate: {
    width: '95%',
    padding: 10,
    margin: 10,
    backgroundColor: '#B7D3DF',
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    alignItems: 'center'
  },
  sub: {
    fontSize: 20,
  },
  img: {
    width: 55,
    height: 55,
    borderRadius: 5
  }
});

export default function Dogs(){

 return(
  <SafeAreaView style={styles.container}>
    <Text style={styles.title}> Razas más famosas de perros</Text>
    <ScrollView>
      <View style={styles.cate}>
        <Image source={require("../../images/dogs/french.png")} style={styles.img} />
        <Text style={styles.sub}>Chihuahua</Text>
      </View>
      <View style={styles.cate}>
        <Image source={require("../../images/dogs/chihuahua.jpg")} style={styles.img} />
        <Text style={styles.sub}>French</Text>
      </View>
      <View style={styles.cate}>
        <Image source={require("../../images/dogs/rot.jpg")} style={styles.img} />
        <Text style={styles.sub}>Rottweiler</Text>
      </View>
      <View style={styles.cate}>
        <Image source={require("../../images/dogs/pastor.jpg")} style={styles.img} />
        <Text style={styles.sub}>Pastor Alemán</Text>
      </View>
      <View style={styles.cate}>
        <Image source={require("../../images/dogs/husky.png")} style={styles.img} />
        <Text style={styles.sub}>Siberian Husky</Text>
      </View>
    </ScrollView>
  </SafeAreaView>
 );
};

