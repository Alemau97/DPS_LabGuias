import React from 'react';
import {View,Text, Image, ScrollView, StyleSheet, SafeAreaView, } from 'react-native';

const styles = StyleSheet.create({
  container: {
    width: '100%'
  },  
  title: {
    padding: 5,
    fontSize: 20,
    textAlign: 'center'
  },
  cate: {
    width: '95%',
    padding: 10,
    margin: 10,
    backgroundColor: '#B7D3DF',
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    alignItems: 'center'
  },
  sub: {
    fontSize: 20,
  },
  img: {
    width: 55,
    height: 55,
    borderRadius: 5
  }
});

export default function Cats(){

 return(
  <SafeAreaView style={styles.container}>
    <Text style={styles.title}> Razas más famosas de gatos</Text>
    <ScrollView>
      <View style={styles.cate}>
        <Image source={require("../../images/cats/abisinio.jpg")} style={styles.img} />
        <Text style={styles.sub}>Gato Abisinio</Text>
      </View>
      <View style={styles.cate}>
        <Image source={require("../../images/cats/angora.jpg")} style={styles.img} />
        <Text style={styles.sub}>Gato Angora</Text>
      </View>
      <View style={styles.cate}>
        <Image source={require("../../images/cats/balines.jpeg")} style={styles.img} />
        <Text style={styles.sub}>Gato Balinés</Text>
      </View>
      <View style={styles.cate}>
        <Image source={require("../../images/cats/bengali.jpg")} style={styles.img} />
        <Text style={styles.sub}>Gato Bengalí</Text>
      </View>
      <View style={styles.cate}>
        <Image source={require("../../images/cats/azulruso.jpg")} style={styles.img} />
        <Text style={styles.sub}>Gato Azul Ruso</Text>
      </View>
    </ScrollView>
  </SafeAreaView>
 );
}