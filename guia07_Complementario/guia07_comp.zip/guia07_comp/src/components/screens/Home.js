import React from 'react';
import {View,Text,StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  title: {
    fontSize: 20,
    padding: 20
  }
})

export default function Home(props){

  const {navigation} = props;

 return(
  <View>
    <Text style={styles.title}>¡Hola! En esta app tendrás la posibilidad de conocer algunas razas de animales como perros y gatos :) </Text>
    
  </View>
 );
}
