import React, {useState} from 'react';
import { View, StyleSheet, Image, Text, ScrollView, Modal, Button, TouchableHighlight } from 'react-native';

export default function App() {

  const [modalHabitaciones, setmodalHabitaciones] = useState(false);
  const [modalHabitaciones1, setmodalHabitaciones1] = useState(false);
  const [modalHabitaciones2, setmodalHabitaciones2] = useState(false);

  const [modalServs, setmodalServs] = useState(false);
  const [modalServs1, setmodalServs1] = useState(false);
  const [modalServs2, setmodalServs2] = useState(false);
  const [modalServs3, setmodalServs3] = useState(false);
  const [modalServs4, setmodalServs4] = useState(false);

  const [modalinteres, setmodalinteres] = useState(false);
  const [modalinteres1, setmodalinteres1] = useState(false);
  const [modalinteres2, setmodalinteres2] = useState(false);
  const [modalinteres3, setmodalinteres3] = useState(false);

  return (
    <>
      <ScrollView>
        <Modal transparent={true} animationType="slide" visible={modalHabitaciones} onRequestClose={()=>{
          alert('Modal has been closed')
        }}>
        <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Habitación normal</Text>
            <Text>Una habitación perfecta para 2 personas, contiene 1 cama matrimonial o 2 camas individuales, solo por $60 la noche.</Text>
            <Button title="Cerrar" onPress={()=>{setmodalHabitaciones(!modalHabitaciones)}}></Button>
          </View>
        </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalHabitaciones1} onRequestClose={()=>{
          alert('Modal has been closed')
        }}>
        <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Habitación suit</Text>
            <Text>Una habitación para personas más exigentes con la comodidad, posee 1 cama king size, 1 cama individual, solo por $150 la noche.</Text>
            <Button title="Cerrar" onPress={()=>{setmodalHabitaciones1(!modalHabitaciones1)}}></Button>
          </View>
        </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalHabitaciones2} onRequestClose={()=>{
          alert('Modal has been closed')
        }}>
        <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Habitación suit presidencial</Text>
            <Text>Una habitación perfecta en todos los sentidos, siéntete libre en un espacio enorme dentro de tu propia habitación, 
              contiene 1 cama queen size, 1 cama king size y 2 camas individuales. Solo por $300 la noche.
            </Text>
            <Button title="Cerrar" onPress={()=>{setmodalHabitaciones2(!modalHabitaciones2)}}></Button>
          </View>
        </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalServs} onRequestClose={()=>{
          alert('Modal has been closed')
        }}>
        <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Bar Neptuno</Text>
            <Text>Para mayores de 18 años, bebidas gratis a excepción de vinos Saunt Laurent ($150 botella)</Text>
            <Button title="Cerrar" onPress={()=>{setmodalServs(!modalServs)}}></Button>
          </View>
        </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalServs1} onRequestClose={()=>{
          alert('Modal has been closed')
        }}>
        <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Piscina</Text>
            <Text>Ven a nadar y olvídate de tus problemas, horario disponible 7:00 a.m. - 10:00 p.m.</Text>
            <Button title="Cerrar" onPress={()=>{setmodalServs1(!modalServs1)}}></Button>
          </View>
        </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalServs2} onRequestClose={()=>{
          alert('Modal has been closed')
        }}>
        <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Sauna</Text>
            <Text>Ven a disfrutar de nuestro sauna especializado, te brindamos todo lo necesario. Tiene un costo extra de $25</Text>
            <Button title="Cerrar" onPress={()=>{setmodalServs2(!modalServs2)}}></Button>
          </View>
        </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalServs3} onRequestClose={()=>{
          alert('Modal has been closed')
        }}>
        <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Gimnasio</Text>
            <Text>Te sientes con unos kilitos de más? No pierdas tiempo y ven a quemarlos! acceso gratuito a todas las máquinas.</Text>
            <Button title="Cerrar" onPress={()=>{setmodalServs3(!modalServs3)}}></Button>
          </View>
        </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalServs4} onRequestClose={()=>{
          alert('Modal has been closed')
        }}>
        <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Restaurante Buffet</Text>
            <Text>Incluye desayuno y almuerzo gratis, snacks ilimitados por $15 extra</Text>
            <Button title="Cerrar" onPress={()=>{setmodalServs4(!modalServs4)}}></Button>
          </View>
        </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalinteres} onRequestClose={()=>{
          alert('Modal has been closed')
        }}>
        <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>La Gran Vía</Text>
            <Text>Ven a conocer todos los lugares de venta de comida, ropa, muebles, etc. En este grandioso centro comercial</Text>
            <Button title="Cerrar" onPress={()=>{setmodalinteres(!modalinteres)}}></Button>
          </View>
        </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalinteres1} onRequestClose={()=>{
          alert('Modal has been closed')
        }}>
        <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Café Vivero</Text>
            <Text>Ven a disfrutar de los cafés más exclusivos de la ciudad y disfruta de la naturalez a sus alrededores</Text>
            <Button title="Cerrar" onPress={()=>{setmodalinteres1(!modalinteres1)}}></Button>
          </View>
        </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalinteres2} onRequestClose={()=>{
          alert('Modal has been closed')
        }}>
        <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Soho Cascadas</Text>
            <Text>Otro centro comercial, aunque más pequeño pero perfecto para dar un pequeño vueltín en familia</Text>
            <Button title="Cerrar" onPress={()=>{setmodalinteres2(!modalinteres2)}}></Button>
          </View>
        </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalinteres3} onRequestClose={()=>{
          alert('Modal has been closed')
        }}>
        <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Volcán de San Salvador</Text>
            <Text>Ven a disfrutar de preciosas vistas de la ciudad desde lo alto, puedes hacer una parada en los diferentes cafés y restaurantes con 
            estupenda vista</Text>
            <Button title="Cerrar" onPress={()=>{setmodalinteres3(!modalinteres3)}}></Button>
          </View>
        </View>
        </Modal>

        <View style={{flexDirection: 'row'}}>
          <Image 
            style={styles.banner}
            source={require('./src/sheraton.jpg')}
          />
        </View>

        <View style={styles.contenedor}>
          <Text style={styles.titulo}>Habitaciones disponibles</Text>
          <ScrollView horizontal>
            <View>
              <TouchableHighlight onPress={()=>{setmodalHabitaciones(!modalHabitaciones)}}>
                <Image 
                  style={styles.habs}
                  source={require('./src/normal.jpg')}
                />
              </TouchableHighlight>
            </View>
            <View>
              <TouchableHighlight onPress={()=>{setmodalHabitaciones1(!modalHabitaciones1)}}>
                <Image 
                  style={styles.habs}
                  source={require('./src/suit.jpg')}
                />
              </TouchableHighlight>
            </View>
            <View>
              <TouchableHighlight onPress={()=>{setmodalHabitaciones2(!modalHabitaciones2)}}>
                <Image 
                  style={styles.habs}
                  source={require('./src/suitpre.jpg')}
                />
              </TouchableHighlight>
            </View>
          </ScrollView>

          <Text style={styles.titulo}>Servicios disponibles</Text>
          <ScrollView horizontal>
            <View>
              <TouchableHighlight onPress={()=>{setmodalServs4(!modalServs4)}}>
                <Image 
                  style={styles.habs}
                  source={require('./src/restaurante.jpg')}
                />
              </TouchableHighlight>
            </View>
            <View>
              <TouchableHighlight onPress={()=>{setmodalServs(!modalServs)}}>
                <Image 
                  style={styles.habs}
                  source={require('./src/bar.jpg')}
                />
              </TouchableHighlight>
            </View>
            <View>
              <TouchableHighlight onPress={()=>{setmodalServs1(!modalServs1)}}>
                <Image 
                  style={styles.habs}
                  source={require('./src/pool.jpg')}
                />
              </TouchableHighlight>
            </View>
            <View>
              <TouchableHighlight onPress={()=>{setmodalServs2(!modalServs2)}}>
                <Image 
                  style={styles.habs}
                  source={require('./src/sauna.jpg')}
                />
              </TouchableHighlight>
            </View>
            <View>
              <TouchableHighlight onPress={()=>{setmodalServs3(!modalServs3)}}>
                <Image 
                  style={styles.habs}
                  source={require('./src/gym.jpg')}
                />
              </TouchableHighlight>
            </View>
          </ScrollView>

          <Text style={styles.titulo}>Lugares de interés</Text>
          <View style={styles.listado}>
            <View style={styles.listaItem}>
              <TouchableHighlight onPress={()=>{setmodalinteres(!modalinteres)}}>
                <Image 
                  style={styles.interes}
                  source={require('./src/lgv.jpg')}
                />
              </TouchableHighlight>
            </View>
            
            <View style={styles.listaItem}>
              <TouchableHighlight onPress={()=>{setmodalinteres1(!modalinteres1)}}>
                <Image 
                  style={styles.interes}
                  source={require('./src/cafe.jpg')}
                />
              </TouchableHighlight>
            </View>

            <View style={styles.listaItem}>
              <TouchableHighlight onPress={()=>{setmodalinteres2(!modalinteres2)}}>
                <Image 
                  style={styles.interes}
                  source={require('./src/soho.jpg')}
                />
              </TouchableHighlight>
            </View>
            
            <View style={styles.listaItem}>
              <TouchableHighlight onPress={()=>{setmodalinteres3(!modalinteres3)}}>
                <Image 
                  style={styles.interes}
                  source={require('./src/volcan.png')}
                />
              </TouchableHighlight>
            </View>
          </View>
        </View>
      </ScrollView>
    </>
  )
}

const styles = StyleSheet.create({
  banner: {
    height: 250,
    flex: 1
  },
  titulo: {
    fontWeight: 'bold',
    fontSize: 24,
    marginVertical: 10
  },
  contenedor: {
    marginHorizontal: 10,
  },
  habs: {
    width: 250,
    height: 250,
    margin: 10,
    borderRadius: 10
  },
  interes: {
    width: '100%',
    height: 200,
    marginVertical: 5,
    borderRadius: 10
  },
  listaItem: {
    flexBasis: '50%',
  },
  vistaModal: {
    backgroundColor: '#000000aa',
    flex: 1
  },
  Modal: {
    backgroundColor: '#fff',
    margin: 50,
    padding: 40,
    borderRadius: 10,
    flex: 1
  },
  subtitulo: {
    fontWeight: 'bold',
    fontSize: 14,
    justifyContent: 'center',
  }
  
});
