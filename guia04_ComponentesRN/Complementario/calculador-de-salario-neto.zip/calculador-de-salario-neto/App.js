/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, {useState, useEffect} from 'react';
import {SafeAreaView,StyleSheet,View,Text,StatusBar} from 'react-native';
import color from './src/utils/colors';
import Form from './src/components/Form'
import Footer from './src/components/Footer';
import Result from './src/components/Result';

export default function App(){

  const [nombre, setNombre] = useState(null);
  const [salario, setSalario] = useState(null);
  const [total, setTotal] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    if (nombre && salario) calculate();
    else reset();
    }, [nombre, salario]);

  const calculate = () =>{
    reset();
    if (!nombre) {
      setErrorMessage('Añade el nombre del empleado');
    } else if (!salario) {
      setErrorMessage('Añade el salario del empleado');
    } 
    else {
      const Isss = salario * 0.03;
      const Afp = salario * 0.04;
      const Renta = salario * 0.05;
      const totalDesc = Isss + Afp + Renta;
      const salarioNeto = salario - totalDesc;
      setTotal({
      isss: Isss,
      afp: Afp,
      renta: Renta,
      totalSalario: salarioNeto,
      });
    }
  }

  const reset = () => {
    setErrorMessage('');
    setTotal(null);
 };

  return(
    <>
      <StatusBar barStyle="light-content"/>
      <SafeAreaView style={styles.Header}>
        <Text style={styles.HeadApp}>Calculador de salario neto</Text>
        <Form 
          setNombre={setNombre}
          setSalario={setSalario}
        />
      </SafeAreaView>
      <Result 
        nombre = {nombre}
        salario = {salario}
        total = {total}
        errorMessage = {errorMessage}
      />
      <Footer />
    </>
  );
}

const styles = StyleSheet.create({
  Header:{
    backgroundColor: color.PRIMARY_COLOR,
    height:200,
    borderBottomLeftRadius:30,
    borderBottomRightRadius:30,
    alignItems:'center'
 },
  HeadApp:{
    fontSize: 20,
    fontWeight: "bold",
    color: "#fff",
    textAlign: "center",
    margin: 30
  }
})
