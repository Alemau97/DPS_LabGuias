import React from 'react';
import { Text, View, StyleSheet, TouchableHighlight, ScrollView } from 'react-native';

const Reserva = ({item, eliminarReserva}) => {
  const dialogoEliminar = id => {
    console.log('Eliminando...', id);
    eliminarReserva(id);
  }

  return (
    <View style={styles.Reserva}>
      <View>
        <Text style={styles.label}>Nombre: </Text>   
        <Text style={styles.texto}>{item.nombre}</Text>  
      </View>
      <View>
        <Text style={styles.label}>Área de comida (Fumadores/ No fumadores): </Text>   
        <Text style={styles.texto}>{item.area}</Text>  
      </View>
      <View>
      <View>
        <Text style={styles.label}>Cantidad de personas: </Text>   
        <Text style={styles.texto}>{item.cantidad}</Text>  
      </View>
      <View>
        <Text style={styles.label}>Fecha de reserva: </Text>   
        <Text style={styles.texto}>{item.fecha}</Text>  
      </View>
      <View>
        <Text style={styles.label}>Hora de reserva:  </Text>   
        <Text style={styles.texto}>{item.hora}</Text>  
      </View>
        <TouchableHighlight onPress={()=>dialogoEliminar(item.id)} style={styles.btnEliminar}>
          <Text style={styles.textoEliminar}>Eliminar reserva &times; </Text>
        </TouchableHighlight>
      </View>
    </View>
  );

}

const styles = StyleSheet.create({
  Reserva: {
    backgroundColor: '#FFF',
    borderBottomColor: '#e1e1e1',
    borderStyle: 'solid',
    borderBottomWidth: 1,
    paddingVertical: 20,
    paddingHorizontal: 10
  },
  label: {
    fontWeight: 'bold',
    fontSize: 18,
    marginTop: 20
  },
  texto: {
    fontSize: 18,
  },
  btnEliminar: {
    padding: 10,
    backgroundColor: 'red',
    marginVertical: 10
  },
  textoEliminar: {
    color: '#FFF',
    fontWeight: 'bold',
    textAlign: 'center'
  }
});

export default Reserva;