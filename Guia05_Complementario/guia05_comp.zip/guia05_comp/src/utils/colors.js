export default{
  PRIMARY_COLOR: '#112443',
  BUTTON_COLOR: '#ddf0ff'
}