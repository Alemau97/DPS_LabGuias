import React, { Component } from 'react';
import { StyleSheet, WebView} from 'react-native';

class App extends Component {

  render() {

    return (
      <WebView
        style={styles.WebViewStyle}
        source={require('./components/index.html')}
        javaScriptEnabled={true}
        domStorageEnabled={true}
      />
    );
  }
}

export default App;

const styles = StyleSheet.create({
  WebViewStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 0.5,
    marginTop: 30,
  },
});



